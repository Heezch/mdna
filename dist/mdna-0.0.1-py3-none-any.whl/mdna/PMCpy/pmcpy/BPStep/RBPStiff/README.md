# RBPStiff

Clone with all submodules
```console
git clone --recurse-submodules -j8 git@github.com:eskoruppa/RBPStiff.git
```


Parameter files taken from [NucleosomeMMC](https://github.com/SchiesselLab/NucleosomeMMC) ([Eslami-Mossallam et al. (2016)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0156905)).

