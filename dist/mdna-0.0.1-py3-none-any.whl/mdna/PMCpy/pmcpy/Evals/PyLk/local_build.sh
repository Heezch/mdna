#!/bin/bash
# Compile cython implementation of writhe map
python3 setup.py build_ext --inplace