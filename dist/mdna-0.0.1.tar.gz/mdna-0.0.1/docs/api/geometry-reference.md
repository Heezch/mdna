# Geometry classes

## Rigid Nucleobase class
:::mdna.geometry.ReferenceBase

## Rigid Base Parameter class
:::mdna.geometry.NucleicFrames