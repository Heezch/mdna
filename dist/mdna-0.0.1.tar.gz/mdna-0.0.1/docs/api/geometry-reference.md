# Geometry classes

## Rigid Nucleobase class
:::pymdna.geometry.ReferenceBase

## Rigid Base Parameter class
:::pymdna.geometry.NucleicFrames