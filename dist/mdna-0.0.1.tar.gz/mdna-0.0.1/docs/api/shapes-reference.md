# Shapes class
::: pymdna.utils.Shapes