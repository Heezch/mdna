# Shapes class
::: mdna.utils.Shapes