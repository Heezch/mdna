# Build 

<!-- ## Generate DNA structure  -->
<!-- ### Generate DNA structure with `make()` -->
::: mdna.nucleic
    handler: python
    options:
        members:
            - make
            - connect
        show_root_heading: false
        show_source: false


::: mdna.nucleic.Nucleic
    handler: python
    options:
        members:
            - extend
        show_root_heading: false
        show_source: false
<!-- ## Extend DNA structure
::: mdna.nucleic.Nucleic.extend

## Connect two DNA strands
::: mdna.nucleic.connect -->

